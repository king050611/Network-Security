# attacker.py
import socket
import pickle
from threading import Thread

def handle_alice(alice_conn):
    try:
        print("[Attacker] Blocked Alice's connection!")

        # Get message from Alice
        data = pickle.loads(alice_conn.recv(4096))
        A = data['public_key']
        mode = data['mode']
        pwd = data.get('password', 'None')
        print(f"[Attacker] get public key: {A}, model: {mode}, code: {pwd}")

        # connect to Bob
        bob_conn = socket.socket()
        bob_conn.connect(('127.0.0.1', 8888))
        print("[Attacker] connect to Bob")

        # send Alice's message to Bob
        bob_conn.send(pickle.dumps(data))

        # Get Bob's public key
        B_data = pickle.loads(bob_conn.recv(4096))
        B = B_data['public_key']
        print(f"[Attacker] get Bob's public key: {B}")

        # 发送给 Alice
        alice_conn.send(pickle.dumps({'public_key': B}))

        print(f"[Attacker] Attack success! Model: {mode}")
        if mode == 3 and pwd != "123456":
            print("[Attacker] The password is incorrect, but it has been forwarded (Bob will reject it).")

        alice_conn.close()
        bob_conn.close()

    except Exception as e:
        print(f"[Attacker] Error: {e}")

def main():
    attacker = socket.socket()
    attacker.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    attacker.bind(('127.0.0.1', 8889))
    attacker.listen(1)
    print("[Attacker] Listening on 8889, waiting for Alice...")

    while True:
        conn, addr = attacker.accept()
        Thread(target=handle_alice, args=(conn,), daemon=True).start()

if __name__ == "__main__":
    main()